<template>
  <div class="app-container">
    <el-card header="三级路由 - menu1-2">
      <router-view />
    </el-card>
  </div>
</template>
