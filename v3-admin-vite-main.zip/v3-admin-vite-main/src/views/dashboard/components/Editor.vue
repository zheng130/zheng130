<template>
  <div class="app-container center">
    <el-empty description="欢迎来到 editor 角色专属首页" />
  </div>
</template>

<style lang="scss" scoped>
.center {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
